﻿namespace Core.Models.Enums
{
    public enum UserType
    {
        User,
        Restaurant
    }
}
