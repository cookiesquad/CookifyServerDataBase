﻿namespace Core.Interfaces
{
    using Core.Models.Identity;

    public interface IApplicationUserService : IBaseEntityService<ApplicationUser>
    {
    }
}
