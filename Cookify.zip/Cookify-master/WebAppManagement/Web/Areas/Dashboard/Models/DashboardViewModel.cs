﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Areas.Dashboard.Models
{
    public class DashboardViewModel
    {
        public int MobileApplicationUsersCount { get; set; }
    }
}
